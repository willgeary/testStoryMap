var createBTN = function (parent, label, radius) {
	if (!parent) parent = setSVG

	var gbtn = parent.append('g');

	gbtn.append('text')
		.attr('class', 'label-btn')
		.attr('text-anchor', 'middle')
		.attr('x', btnAttr.width * .5)
		.attr('y', btnAttr.height * .5)
		.attr('dy', '.3em')
		.text(label)

	gbtn.insert('rect', 'text')
		.attr('class', 'bg-btn')
		.attr('width', btnAttr.width)
		.attr('height', btnAttr.height)
		.attr('rx', function () { 
			if (radius) return radius
			return null
		})
		.attr('ry', function () { 
			if (radius) return radius
			return null
		})

	return gbtn
}