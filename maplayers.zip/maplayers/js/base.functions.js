var width = function () {
	if (self.innerHeight) {
		return self.innerWidth
	}
	if (document.documentElement && document.documentElement.clientWidth) {
		return document.documentElement.clientWidth
	}
	if (document.body) {
		return document.body.clientWidth
	}
}

var height = function () {
	if (self.innerHeight) {
		return self.innerHeight
	}
	if (document.documentElement && document.documentElement.clientHeight) {
		return document.documentElement.clientHeight
	}
	if (document.body) {
		return document.body.clientHeight
	}
}

d3.selection.prototype.moveToFront = function() {
	return this.each(function() {
		this.parentNode.appendChild(this)
	})
}

d3.selection.prototype.toggleClass = function(classname) {
	return this.each(function() {
		var domNode = d3.select(this)
		if (domNode.classed(classname)) {
			domNode.classed(classname, false)
		} else {
			domNode.classed(classname, true)
		}
	})
}

function numberWithCommas (x) {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}